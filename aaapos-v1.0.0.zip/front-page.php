<?php
/**
 * The front page template file
 *
 * Only shows the theme's built-in homepage sections (hero, products,
 * categories, brands, etc.) when the page currently assigned as the
 * site's static front page has the "Homepage Sections" page template
 * selected (Page Attributes > Template).
 *
 * If a different page is set as the homepage instead (Settings >
 * Reading), that page's own content is shown as-is - nothing from
 * this file gets injected into it.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$aaapos_front_page_id = get_option('page_on_front');
$aaapos_use_sections   = $aaapos_front_page_id
    && get_page_template_slug($aaapos_front_page_id) === 'page-templates/homepage-sections.php';

if ($aaapos_use_sections) :
?>

<div class="homepage-wrapper">
    <?php
    // Display custom page content if it exists (editor content)
    if (have_posts()) :
        while (have_posts()) : the_post();
            if (trim(get_the_content())) :
                ?>
                <div class="container">
                    <div class="homepage-custom-content">
                        <?php the_content(); ?>
                    </div>
                </div>
                <?php
            endif;
        endwhile;
    endif;

    // Hero Section
    get_template_part('template-parts/hero/hero-section');

    // Product Categories
    if (get_theme_mod('show_categories', true)) {
        get_template_part('template-parts/sections/product-categories');
    }

    // Featured Products
    if (get_theme_mod('show_featured_products', true)) {
        get_template_part('template-parts/sections/featured-products');
    }

    // Brands
    if (get_theme_mod('show_brands', true)) {
        get_template_part('template-parts/sections/Brands');
    }

    // Deals & Offers
    if (get_theme_mod('show_deals', true)) {
        get_template_part('template-parts/sections/deals-offers');
    }

    // Testimonials
    if (get_theme_mod('show_testimonials', true)) {
        get_template_part('template-parts/sections/testimonials');
    }

    // Blog Preview
    if (get_theme_mod('show_blog', true)) {
        get_template_part('template-parts/sections/blog-preview');
    }

    // Newsletter
    if (get_theme_mod('show_newsletter', true)) {
        get_template_part('template-parts/sections/newsletter');
    }
    ?>
</div>

<?php
else :
    // A different page is assigned as the homepage - show its own
    // content only, exactly like a normal static page.
    ?>
    <main id="primary" class="site-main">
        <div class="container">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/content/content-page');
            endwhile;
            ?>
        </div>
    </main>
    <?php
endif;

get_footer();