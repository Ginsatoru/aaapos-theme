<?php
/**
 * Hero Section - CLASSIC design markup
 *
 * Included by template-parts/hero/hero-section.php when
 * Customizer > Hero Section > Hero Design = Classic. Relies on
 * aaapos_resolve_media_url() and aaapos_ascend_words(), defined in the
 * dispatcher file that includes this one.
 *
 * Performance: the first visible hero image (video fallback, first slide, or
 * static image) loads eagerly with high priority, since it is the page's main
 * content (LCP). Later slides stay lazy. inc/enqueue.php preloads the same image.
 */

    // =========================================================================
    // CLASSIC DESIGN (product carousel / notification banner / slideshow or video)
    // =========================================================================

    $media_type = get_theme_mod('hero_media_type', 'image');
    $overlay_opacity = get_theme_mod('hero_overlay_opacity', 0.6);

    $hero_title = get_theme_mod('hero_title', 'Premium Feed & Supplies');
    $hero_title_highlight = get_theme_mod('hero_title_highlight', 'For Your Beloved Pets & Livestock');
    $hero_subtitle = get_theme_mod(
        'hero_classic_subtitle',
        'Your trusted local supplier for premium pet food, animal feed, farm supplies, and everything your animals need. From dogs and cats to horses, poultry, and livestock.',
    );
    $primary_btn_text = get_theme_mod('hero_primary_button_text', 'Shop All Products');
    $primary_btn_link = get_theme_mod('hero_primary_button_link', '/shop');
    $secondary_btn_text = get_theme_mod('hero_secondary_button_text', 'About Our Store');
    $secondary_btn_link = get_theme_mod('hero_secondary_button_link', '/about');

    // Notification Banner Settings
    $show_notification = get_theme_mod('hero_show_notification', true);
    $notification_icon = get_theme_mod('hero_notification_icon');
    $notification_title = get_theme_mod('hero_notification_title', 'RetailManager Update Available!');
    $notification_text = get_theme_mod('hero_notification_text', 'Discover the latest features, improvements, and enhancements that will boost your retail operations.');
    $notification_btn_text = get_theme_mod('hero_notification_btn_text', 'LEARN ABOUT NEW UPDATES');
    $notification_btn_link = get_theme_mod('hero_notification_btn_link', '#');

    // Product carousel settings
    $show_product_carousel = get_theme_mod('hero_classic_show_product_carousel', true);
    $products = array();
    for ($i = 1; $i <= 4; $i++) {
        $products[] = array(
            'image' => get_theme_mod("hero_product_{$i}_image"),
            'name'  => get_theme_mod("hero_product_{$i}_name", 'Product Name'),
            'price' => get_theme_mod("hero_product_{$i}_price", '$99'),
            'link'  => get_theme_mod("hero_product_{$i}_link", '#'),
        );
    }

    // Default fallback image (used for the slideshow/static background
    // when no slide image has been uploaded for a given slot).
    $default_image = get_template_directory_uri() . '/images/herobg.png';
    $default_images = array($default_image, $default_image, $default_image, $default_image);

    // hero-classic-mode scopes assets/css/components/hero-classic.css so it
    // never collides with the Modern design's hero.css class names.
    $hero_class = 'hero-section hero-classic-mode hero-simple';
    if ($media_type === 'video') {
        $hero_class .= ' hero-video-mode';
    } else {
        $hero_class .= ' hero-image-mode';
    }

    if ($media_type === 'video') {
        $video_loop = get_theme_mod('hero_video_loop', true);
        $video_mute = get_theme_mod('hero_video_mute', true);
        $video_mobile_fallback = get_theme_mod('hero_video_mobile_fallback', true);

        $video_id = get_theme_mod('hero_video_webm', '');
        $video_url = $video_id ? wp_get_attachment_url($video_id) : '';

        $fallback_image_id = get_theme_mod('hero_video_fallback', '');
        $fallback_image_url = $fallback_image_id
            ? wp_get_attachment_image_url($fallback_image_id, 'full')
            : '';

        $video_data_attrs = sprintf(
            'data-video-url="%s" data-fallback-image="%s" data-video-loop="%s" data-video-mute="%s" data-mobile-fallback="%s"',
            esc_url($video_url),
            esc_url($fallback_image_url),
            $video_loop ? 'true' : 'false',
            $video_mute ? 'true' : 'false',
            $video_mobile_fallback ? 'true' : 'false',
        );
    } else {
        $video_data_attrs = '';

        $enable_slideshow = get_theme_mod('hero_enable_slideshow', true);

        $hero_slide_1 = get_theme_mod('hero_slide_1');
        $hero_slide_2 = get_theme_mod('hero_slide_2');
        $hero_slide_3 = get_theme_mod('hero_slide_3');
        $hero_slide_4 = get_theme_mod('hero_slide_4');

        $slideshow_speed = get_theme_mod('hero_slideshow_speed', 5000);

        $slides = array($hero_slide_1, $hero_slide_2, $hero_slide_3, $hero_slide_4);

        if (!$enable_slideshow) {
            $hero_class .= ' hero-static';
        }
    }

    // The first visible hero image: load now, with high priority
    $hero_img_priority = 'loading="eager" fetchpriority="high" decoding="async"';
    $hero_img_priority_args = array('loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async');
    ?>

    <section class="<?php echo esc_attr($hero_class); ?>" <?php echo $video_data_attrs; ?>>

        <?php if ($media_type === 'video'): ?>
            <!-- Video Background -->
            <div class="hero-video-background">
                <?php if ($video_url && $video_url): ?>
                    <div class="hero-video-container">
                        <?php if ($fallback_image_url): ?>
                            <img src="<?php echo esc_url($fallback_image_url); ?>"
                                 alt="<?php echo esc_attr($hero_title); ?>"
                                 class="video-fallback-image"
                                 <?php echo $hero_img_priority; ?>>
                        <?php else: ?>
                            <img src="<?php echo esc_url($default_images[0]); ?>"
                                 alt="<?php echo esc_attr($hero_title); ?>"
                                 class="video-fallback-image"
                                 <?php echo $hero_img_priority; ?>>
                        <?php endif; ?>

                        <div class="video-controls">
                            <button class="video-play-btn" aria-label="Play video">
                                <svg class="play-icon" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M8 5v14l11-7z"/>
                                </svg>
                            </button>
                            <button class="video-pause-btn" aria-label="Pause video" style="display: none;">
                                <svg class="pause-icon" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
                                </svg>
                            </button>
                            <button class="video-mute-btn" aria-label="<?php echo $video_mute ? 'Unmute video' : 'Mute video'; ?>">
                                <?php if ($video_mute): ?>
                                    <svg class="mute-icon" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
                                    </svg>
                                <?php else: ?>
                                    <svg class="unmute-icon" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
                                    </svg>
                                <?php endif; ?>
                            </button>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="hero-static-background">
                        <?php if ($fallback_image_url): ?>
                            <img src="<?php echo esc_url($fallback_image_url); ?>"
                                 alt="<?php echo esc_attr($hero_title); ?>"
                                 class="hero-static-image"
                                 <?php echo $hero_img_priority; ?>>
                        <?php else: ?>
                            <img src="<?php echo esc_url($default_images[0]); ?>"
                                 alt="<?php echo esc_attr($hero_title); ?>"
                                 class="hero-static-image"
                                 <?php echo $hero_img_priority; ?>>
                        <?php endif; ?>
                        <div class="slide-overlay" style="background: rgba(0, 0, 0, <?php echo esc_attr($overlay_opacity); ?>);"></div>
                    </div>
                <?php endif; ?>
                <div class="slide-overlay" style="background: rgba(0, 0, 0, <?php echo esc_attr($overlay_opacity); ?>);"></div>
            </div>

        <?php else: ?>
            <!-- Image Background -->
            <?php if ($enable_slideshow): ?>
                <div class="hero-slider"
                     data-autoplay="true"
                     data-delay="<?php echo esc_attr($slideshow_speed); ?>"
                     data-pause-hover="true"
                     data-keyboard="true"
                     data-dots="false"
                     data-arrows="false"
                     data-loop="true">
                    <div class="hero-slides">
                        <?php foreach ($slides as $index => $slide_id): ?>
                            <?php $is_first = ($index === 0); ?>
                            <div class="hero-slide">
                                <?php if ($slide_id): ?>
                                    <?php echo wp_get_attachment_image(
                                        $slide_id,
                                        'full',
                                        false,
                                        array_merge(
                                            array(
                                                'alt' => esc_attr($hero_title),
                                                'class' => 'hero-slide-image',
                                            ),
                                            $is_first ? $hero_img_priority_args : array('loading' => 'lazy'),
                                        ),
                                    ); ?>
                                <?php else: ?>
                                    <img src="<?php echo esc_url($default_images[$index]); ?>"
                                         alt="<?php echo esc_attr($hero_title); ?>"
                                         class="hero-slide-image"
                                         <?php echo $is_first ? $hero_img_priority : 'loading="lazy"'; ?>>
                                <?php endif; ?>
                                <div class="slide-overlay" style="background: rgba(0, 0, 0, <?php echo esc_attr($overlay_opacity); ?>);"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="hero-static-background">
                    <?php if ($hero_slide_1): ?>
                        <?php echo wp_get_attachment_image($hero_slide_1, 'full', false, array_merge(array(
                            'alt' => esc_attr($hero_title),
                            'class' => 'hero-static-image',
                        ), $hero_img_priority_args)); ?>
                    <?php else: ?>
                        <img src="<?php echo esc_url($default_images[0]); ?>"
                             alt="<?php echo esc_attr($hero_title); ?>"
                             class="hero-static-image"
                             <?php echo $hero_img_priority; ?>>
                    <?php endif; ?>
                    <div class="slide-overlay" style="background: rgba(0, 0, 0, <?php echo esc_attr($overlay_opacity); ?>);"></div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Hero Content Container -->
        <div class="hero-content-wrapper">
            <div class="hero-content-container">

                <!-- Left Side: Content -->
                <div class="hero-content">
                    <h1 class="hero-title">
                        <?php echo esc_html($hero_title); ?>
                        <?php if ($hero_title_highlight): ?>
                        <span class="hero-title-highlight"><?php echo esc_html($hero_title_highlight); ?></span>
                        <?php endif; ?>
                    </h1>

                    <p class="hero-subtitle">
                        <?php echo esc_html($hero_subtitle); ?>
                    </p>

                    <div class="hero-buttons">
                        <?php if ($primary_btn_text): ?>
                            <a href="<?php echo esc_url($primary_btn_link); ?>" class="hero-btn hero-btn-primary">
                                <?php echo esc_html($primary_btn_text); ?>
                                <svg class="hero-btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 7l5 5m0 0l-5 5m5-5H6"></path>
                                </svg>
                            </a>
                        <?php endif; ?>

                        <?php if ($secondary_btn_text): ?>
                            <a href="<?php echo esc_url($secondary_btn_link); ?>" class="hero-btn hero-btn-secondary">
                                <svg class="hero-btn-icon-left" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <?php echo esc_html($secondary_btn_text); ?>
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Notification Banner -->
                    <?php if ($show_notification): ?>
                    <div class="hero-notification-banner">
                        <div class="notification-content">
                            <?php if ($notification_icon): ?>
                            <div class="notification-icon">
                                <?php echo wp_get_attachment_image($notification_icon, 'thumbnail', false, array(
                                    'alt' => esc_attr($notification_title),
                                )); ?>
                            </div>
                            <?php endif; ?>

                            <div class="notification-text">
                                <h3 class="notification-title"><?php echo esc_html($notification_title); ?></h3>
                                <p class="notification-description"><?php echo esc_html($notification_text); ?></p>
                            </div>
                        </div>

                        <?php if ($notification_btn_text): ?>
                        <a href="<?php echo esc_url($notification_btn_link); ?>" class="notification-btn">
                            <?php echo esc_html($notification_btn_text); ?>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Right Side: Product Carousel - HIDDEN ON MOBILE -->
                <?php if ($show_product_carousel): ?>
                <div class="hero-product-carousel hero-product-side hero-product-desktop-only">
                    <div class="product-carousel-track">
                        <?php foreach ($products as $index => $product): ?>
                            <?php if ($product['image']): ?>
                            <div class="product-slide <?php echo $index === 0 ? 'active' : ''; ?>">
                                <?php $slide_link = $product['link']; ?>
                                <?php if (!empty($slide_link) && $slide_link !== '#'): ?>
                                    <a href="<?php echo esc_url($slide_link); ?>" class="product-slide-link">
                                        <?php echo wp_get_attachment_image($product['image'], 'large', false, array(
                                            'alt' => esc_attr($product['name']),
                                            'class' => 'product-slide-img',
                                        )); ?>
                                    </a>
                                <?php else: ?>
                                    <?php echo wp_get_attachment_image($product['image'], 'large', false, array(
                                        'alt' => esc_attr($product['name']),
                                        'class' => 'product-slide-img',
                                    )); ?>
                                <?php endif; ?>
                                <div class="product-slide-caption">
                                    <span class="product-slide-name"><?php echo esc_html($product['name']); ?></span>
                                    <span class="product-slide-price"><?php echo esc_html($product['price']); ?></span>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                    <!-- Vertical Dot Pill -->
                    <div class="carousel-indicators">
                        <?php foreach ($products as $index => $product): ?>
                            <?php if ($product['image']): ?>
                            <button class="indicator-dot <?php echo $index === 0 ? 'active' : ''; ?>"
                                    data-slide="<?php echo $index; ?>"
                                    aria-label="Go to product <?php echo $index + 1; ?>">
                            </button>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- Loading indicator for videos -->
        <?php if ($media_type === 'video' && $video_url): ?>
            <div class="video-loading" style="display: none;">
                <div class="loading-spinner"></div>
                <span class="loading-text">Loading video...</span>
            </div>
        <?php endif; ?>
    </section>