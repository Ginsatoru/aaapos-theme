/**
 * Page Loading Animation
 * Professional overlay loader with progress bar
 * 
 * @package aaapos-prime
 */

(function () {
  "use strict";

  // Configuration
  const CONFIG = {
    loadDuration: 1800, // Total load time in milliseconds
    fadeOutDuration: 500, // Fade out duration in milliseconds
    minLoadTime: 800, // Minimum time to show loader
  };

  /**
   * Page Loader Class
   */
  class PageLoader {
    constructor() {
      // Check if loader should be enabled
      if (!document.body.classList.contains("page-loading")) {
        return;
      }

      this.loader = document.querySelector(".page-loader-overlay");
      if (!this.loader) {
        return;
      }

      this.progressBar = this.loader.querySelector(".page-loader-progress-bar");
      this.startTime = Date.now();

      this.init();
    }

    init() {
      // Start progress animation
      this.animateProgress();

      // Hide loader after duration
      setTimeout(() => {
        this.hideLoader();
      }, CONFIG.loadDuration);

      // Also hide when page fully loads
      if (document.readyState === "complete") {
        setTimeout(() => {
          this.hideLoader();
        }, CONFIG.loadDuration);
      } else {
        window.addEventListener(
          "load",
          () => {
            setTimeout(() => {
              this.hideLoader();
            }, CONFIG.loadDuration);
          },
          { once: true }
        );
      }
    }

    animateProgress() {
      if (!this.progressBar) return;

      // Trigger progress bar animation
      requestAnimationFrame(() => {
        this.progressBar.style.width = "100%";
      });
    }

    hideLoader() {
      if (!this.loader) return;

      // Calculate elapsed time
      const elapsedTime = Date.now() - this.startTime;
      const remainingTime = Math.max(0, CONFIG.minLoadTime - elapsedTime);

      // Wait for minimum load time if needed
      setTimeout(() => {
        // Add fade-out class
        this.loader.classList.add("fade-out");

        // Remove loader from DOM after fade completes
        setTimeout(() => {
          if (this.loader && this.loader.parentNode) {
            this.loader.remove();
          }
          // Enable scrolling
          document.body.classList.remove("page-loading");
        }, CONFIG.fadeOutDuration);
      }, remainingTime);
    }
  }

  /**
   * Initialize when DOM is ready
   */
  function init() {
    new PageLoader();
  }

  // Start when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();