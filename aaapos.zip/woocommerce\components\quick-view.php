<?php
/**
 * Quick view modal component
 */
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="quick-view-modal">
    <div class="quick-view-content">
        <button class="quick-view-close" aria-label="<?php esc_attr_e('Close quick view', 'macedon-ranges'); ?>">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
            </svg>
        </button>

        <div class="quick-view-product">
            <div class="product-images">
                <!-- Product images will be loaded via AJAX -->
            </div>

            <div class="product-summary">
                <!-- Product details will be loaded via AJAX -->
            </div>
        </div>
    </div>
</div>